//And in that light, I find deliverance.
#include<bits/stdc++.h>
#define int long long
using namespace std;

signed main()
{
	freopen("treasure.in","r",stdin);
	freopen("treasure.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1,temp;i<=n;i++)cin>>temp;
	cout<<0;
	return 0;
}

