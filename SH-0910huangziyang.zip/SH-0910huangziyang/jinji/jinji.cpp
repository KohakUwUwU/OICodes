//Project Sekai
#include<bits/stdc++.h>
#define int long long
using namespace std;

signed main()
{
	//ti mu zhen de zhen de zhen de kan bu dong
	//dui bu qi
	return 0;
}

