//Project Sekai
#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N=5005;
int n,m,a[N];
signed main()
{
	//wo zhen de bu hui
	//bao 0 bie guai wo
	//dui bu qi
	return 0;
}

