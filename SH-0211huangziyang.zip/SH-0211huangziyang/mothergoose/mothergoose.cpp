//LizPlum
#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,k;
string str;
signed main()
{
	freopen("mothergoose.in","r",stdin);
	freopen("mothergoose.out","w",stdout);
	cin>>n>>k>>str;
	cout<<1;
	return 0;
}
